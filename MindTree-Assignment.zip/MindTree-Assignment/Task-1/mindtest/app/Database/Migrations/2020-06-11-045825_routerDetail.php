<?php namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class RouterDetail extends Migration
{
	public function up()
	{
		$this->forge->addField([
						'id' =>[
							'type'  => 'INT',
							'unsigned'       => TRUE,
                            'auto_increment' => TRUE
						],
                        'dns_record'          => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '225', 
                                'null'           => TRUE,                               
                        ],
                        'host_name'       => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '100',
                        ],
                        'type' => [
                                'type'           => 'VARCHAR',
                                'constraint'     => '100',
                                'null'           => TRUE,
                        ],
                        'status' => [
                        	'type'  => 'INT',
							'unsigned'       => TRUE,                            
                        ],
                ]);
                $this->forge->addKey('id', TRUE);
                $this->forge->createTable('routerDetail');
	}

	//--------------------------------------------------------------------

	public function down()
	{
		$this->forge->dropTable('routerDetail');
	}
}
