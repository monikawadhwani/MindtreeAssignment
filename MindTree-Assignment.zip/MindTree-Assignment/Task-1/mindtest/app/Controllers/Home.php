<?php namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{		
		return view('user');
	}

	public function setUser(){
		print_r($_POST);
	}

	public function getRouter(){
		$IP = $_SERVER['REMOTE_ADDR']; 

		$dns = dns_get_record("gmail.com");

		$res = $this->checkdatabase($dns);

		$data['dns'] = $dns;

		echo view('manageRouter',$data);
	}

	public function checkdatabase($dns){		
		
		// Create a new class manually
		//$routerDetailModel = new \App\Models\RouterDetailModel();

			foreach ($dns as $d) {	
						
                $dnsData = array();
				if(isset($d['target'])){
					$dnsData['dns_record'] = $d['target'];
				}
				$dnsData['host_name'] = $d['host'];
				$dnsData['type'] = $d['type'];
                $dnsData['status'] = 1;

                //$this->routerDetail->checkdatabase($dnsData);
			}
	}

}
