
To run this project

Open terminal

Go to the project path 

Runcommand : php spark serve




