# Open terminal
# Go to Project Path

#Run command: php spark serve