# Create database mindDb in mysql 

# Run installdb.php