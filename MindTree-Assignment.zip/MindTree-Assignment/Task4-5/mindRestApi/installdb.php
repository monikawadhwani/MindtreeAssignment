<?php

include_once 'config/database.php';

$database = new DatabaseService();
$db = $database->getConnection();

$res = $database->install($db);

echo "Table created successfully";

$database->insertDummyData($db);

echo 'Data inserted successfully';

?>