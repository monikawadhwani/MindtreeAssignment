<?php
include_once 'config/database.php';

class User{
  
    // database connection and table name
    private $conn;
    private $table_name = "Users";
  
    // object properties
    public $id;
    public $first_name;
    public $last_name;
    public $email;
    public $password;
  
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // Get api
	public function getUser($id){
	  
	    // select all query
	    $query = "SELECT * FROM " . $this->table_name . " WHERE id =".$id;
	  
	    // prepare query statement
	    $stmt = $this->conn->prepare($query);
	  
	    // execute query
	    $stmt->execute();
	  
	    return $stmt;
	}


	//post api

	public function createUser(){
		// query to insert record
	    $query = "INSERT INTO
	                " . $this->table_name . "
	            SET
	                first_name=:first_name, last_name=:last_name, email=:email, password=:password";
	  
	    // prepare query
	    $stmt = $this->conn->prepare($query);
	  
	    // sanitize
	    $this->first_name=htmlspecialchars(strip_tags($this->first_name));
	    $this->last_name=htmlspecialchars(strip_tags($this->last_name));
	    $this->email=htmlspecialchars(strip_tags($this->email));
	    $this->password=htmlspecialchars(strip_tags($this->password));	    
	  
	    // bind values
	    $stmt->bindParam(":first_name", $this->first_name);
	    $stmt->bindParam(":last_name", $this->last_name);
	    $stmt->bindParam(":email", $this->email);
	    $stmt->bindParam(":password", $this->password);	    
	  
	    // execute query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;

	}

	// put api

	public function updateUser(){
		// update query
	    $query = "UPDATE
	                " . $this->table_name . "
	            SET
	                first_name = :first_name,
	                last_name = :last_name,
	                email = :email,
	                password = :password
	            WHERE
	                id = :id";
	  
	    // prepare query statement
	    $stmt = $this->conn->prepare($query);
	  
	    // sanitize
	    $this->first_name=htmlspecialchars(strip_tags($this->first_name));
	    $this->last_name=htmlspecialchars(strip_tags($this->last_name));
	    $this->email=htmlspecialchars(strip_tags($this->email));
	    $this->password=htmlspecialchars(strip_tags($this->password));
	    $this->id=htmlspecialchars(strip_tags($this->id));
	  
	    // bind new values
	    $stmt->bindParam(':first_name', $this->first_name);
	    $stmt->bindParam(':last_name', $this->last_name);
	    $stmt->bindParam(':email', $this->email);
	    $stmt->bindParam(':password', $this->password);
	    $stmt->bindParam(':id', $this->id);
	  
	    // execute the query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;

	}

	public function deleteUser(){
			// delete query
	    $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
	  
	    // prepare query
	    $stmt = $this->conn->prepare($query);
	  
	    // sanitize
	    $this->id=htmlspecialchars(strip_tags($this->id));
	  
	    // bind id of record to delete
	    $stmt->bindParam(1, $this->id);
	  
	    // execute query
	    if($stmt->execute()){
	        return true;
	    }
	  
	    return false;
	}

}

?>