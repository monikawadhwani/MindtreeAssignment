<?php
include_once 'config/database.php';
include_once 'user.php';

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
  
// get database connection
$database = new DatabaseService();
$db = $database->getConnection();
  
$user = new User($db);
// get user id
$id = $_GET['id'];

// set user id to be deleted
$user->id = $id;
  
// delete the user
if($user->deleteUser()){
  
    // set response code - 200 ok
    http_response_code(200);
  
    // tell the user
    echo json_encode(array("message" => "user was deleted."));
}
  
// if unable to delete the user
else{
  
    // set response code - 503 service unavailable
    http_response_code(503);
  
    // tell the user
    echo json_encode(array("message" => "Unable to delete user."));
}
?>