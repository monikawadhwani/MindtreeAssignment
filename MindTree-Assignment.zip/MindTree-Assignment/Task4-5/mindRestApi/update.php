<?php
include_once 'config/database.php';
include_once 'user.php';

// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

// instantiate database and user object
$database = new DatabaseService();
$db = $database->getConnection();


/**Get api for user**/
$user = new User($db);	

// get id of user to be edited
$data = json_decode(file_get_contents("php://input"));	  
// set ID property of user to be edited
$user->id = $data->id;
  
// set user property values
$user->first_name = $data->first_name;
$user->last_name = $data->last_name;
$user->email = $data->email;
$user->password = md5($data->password);
  
// update the user
if($user->updateUser()){
  
    // set response code - 200 ok
    http_response_code(200);
  
    // tell the user
    echo json_encode(array("message" => "User was updated."));
}
  
// if unable to update the user, tell the user
else{
  
    // set response code - 503 service unavailable
    http_response_code(503);
  
    // tell the user
    echo json_encode(array("message" => "Unable to update user."));
}


?>
