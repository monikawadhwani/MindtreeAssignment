<?php
// Create a blank image
header('Content-type: image/png');
$image = imagecreatetruecolor(500, 500);
imagesavealpha($png, true);

$trans_colour = imagecolorallocatealpha($image, 255, 255, 255, 127);
imagefill($image, 0, 0, $trans_colour); 

// Allocate a color for the polygon
$col_poly = imagecolorallocatealpha($image, 0, 0, 255,75);

// Draw the polygon
$poly = imagefilledpolygon($image, array(
        300, 200,
        200, 300,
        250, 400,
        350, 400,
        400, 300,
    ),
    5,
    $col_poly);

// Output the picture to the browser
header('Content-type: image/png');

imagepng($image);
imagedestroy($image);
?>